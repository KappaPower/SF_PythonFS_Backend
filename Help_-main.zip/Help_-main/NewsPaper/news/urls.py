from django.urls import path
from .views import PostsList, PostDetail, PostsSearch, PostAdd, PostEdit, PostDelete

urlpatterns = [
    path('', PostsList.as_view()),
    path('<int:pk>', PostDetail.as_view()),
    path('search/', PostsSearch.as_view(), name='search'),
    path('/news/add/', PostAdd.as_view(), name='news_add'),
    path('news/<int:pk>/edit/', PostEdit.as_view(), name='news_edit'),
    path('news/<int:pk>/delete/', PostDelete.as_view(), name='news_delete'),
]
